<?php
if (isset($_POST['name'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $con = mysqli_connect("localhost", "rami", "123456", "ajaxForm");
    $insert = " INSERT INTO user VALUES( '$name','$age' ) ";
    mysqli_query($con, $insert);
}
